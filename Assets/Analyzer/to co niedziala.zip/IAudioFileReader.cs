using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IAudioFileReader
{
    (AudioClip, float) ToAudioClip();
    IEnumerator AnalyzeAudio(AudioClip clip, float bpm);
    List<Tuple<float, float, int>> GetSpikes();
}
