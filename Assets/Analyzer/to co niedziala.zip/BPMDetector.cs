using MathNet.Numerics;
using MathNet.Numerics.IntegralTransforms;
using System;
using System.Numerics;

public class BPMDetector
{
    public Complex[] ApplyFFT(float[] samples)
    {
        int n = samples.Length;
        Complex[] complexSamples = new Complex[n];
        // Convert float samples to Complex[]
        for (int i = 0; i < n; i++)
        {
            complexSamples[i] = new Complex(samples[i], 0);
        }
        // Apply FFT using MathNet.Numerics
        Fourier.Forward(complexSamples);

        return complexSamples;
    }

    public float FindDominantFrequency(Complex[] fftResult, float sampleRate)
    {
        int maxIndex = 0;
        float maxValue = 0;

        // Find the peak magnitude in the FFT result
        for (int i = 0; i < fftResult.Length / 2; i++)
        {
            double magnitude = Math.Sqrt(fftResult[i].Real * fftResult[i].Real + fftResult[i].Imaginary * fftResult[i].Imaginary);
            if (magnitude > maxValue)
            {
                maxValue = (float)magnitude;
                maxIndex = i;
            }
        }

        // Calculate frequency based on the FFT bin and sample rate
        float dominantFrequency = maxIndex * sampleRate / fftResult.Length;
        return dominantFrequency;
    }

    public float EstimateBPM(Complex[] fftResult, float sampleRate)
    {
        float dominantFrequency = FindDominantFrequency(fftResult, sampleRate);
        // BPM is the dominant frequency in Hz times 60
        float bpm = dominantFrequency * 60;
        return bpm;
    }

    /*static void Main()
    {
        // Example usage with sample data
        float[] sampleData = new float[] { 1.0f, 0.5f, -0.5f, -1.0f, 0.5f, 0.0f, -0.5f, 1.0f }; // Example samples
        float sampleRate = 44100;  // Common sample rate for audio files

        BPMDetector bpmDetector = new BPMDetector();
        Complex[] fftResult = bpmDetector.ApplyFFT(sampleData);
        float estimatedBPM = bpmDetector.EstimateBPM(fftResult, sampleRate);

        Console.WriteLine($"Estimated BPM: {estimatedBPM}");
    }*/
}
